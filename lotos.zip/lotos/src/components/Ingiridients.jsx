import NavbarTop from "./NavbarTop"

const Ingiridients = () => {
    return (
        <main className="">
            <NavbarTop />
            <section>
                
            </section>
        </main>
    )
}

export default Ingiridients